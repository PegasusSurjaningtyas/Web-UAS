from django.shortcuts import render
from django.shortcuts import get_object_or_404
from rest_framework.generics import RetrieveUpdateDestroyAPIView
from rest_framework.response import Response
import paho.mqtt.client as mqtt
import time

from ml_model import machinelearning

from .serializers import SensorSerializer
from .models import Sensor


# Create your views here.
def index(request):
    model1 = machinelearning.ml_soil
    model2 = machinelearning.ml_light
    model3 = machinelearning.ml_irrigation
    model4 = machinelearning.ml_humid
    
    
    farm_soil = Sensor.objects.get(name="farm_soil")
    predict1 = model1.predict([float(farm_soil.value),float(farm_soil.value),float(farm_soil.value)])


    farm_humid = Sensor.objects.get(name="farm_humid")

    predict2 = model2.predict([float(farm_humid.value),float(farm_humid.value),float(farm_humid.value)])

    farm_light = Sensor.objects.get(name="farm_light")

    predict3 = model3.predict([float(farm_light.value),float(farm_light.value),float(farm_light.value)])

    farm_irrigation = Sensor.objects.get(name="farm_irrigation")

    predict4 = model4.predict([float(farm_irrigation.value),float(farm_irrigation.value),float(farm_irrigation.value)])


    alarm1 = 'media/green.jpg'
    alarm2 = 'media/green.jpg'
    alarm3 = 'media/green.jpg'
    alarm4 = 'media/green.jpg'
    alarm5 = 'media/green.jpg'
    alarm6 = 'media/green.jpg'
    alarm7 = 'media/green.jpg'
    alarm8 = 'media/green.jpg'
    alarm9 = 'media/green.jpg'
    alarm10 = 'media/green.jpg'
    alarm11 = 'media/green.jpg'
    alarm12 = 'media/green.jpg'
    alarm13 = 'media/green.jpg'


    number = [predict1, predict2, predict3, predict4]
    alarm = [alarm1, alarm2, alarm3, alarm4, alarm5, alarm6, alarm7, alarm8, alarm9, alarm10, alarm11, alarm12, alarm13]

    for i in range(len(number)):
        if number[i] < 80:
            alarm[i] = 'media/red.jpg'


    context = {
        "alarm1" : str(alarm1),
        "alarm2" : str(alarm2),
        "alarm3" : str(alarm3),
        "alarm4" : str(alarm4),
        "alarm5" : str(alarm5),
        "alarm6" : str(alarm6),
        "alarm7" : str(alarm7),
        "alarm8" : str(alarm8),
        "alarm9" : str(alarm9),
        "alarm10" : str(alarm10),
        "alarm11" : str(alarm11),
        "alarm12" : str(alarm12),
        "alarm13" : str(alarm13),

        "farm_soil" : str(farm_soil.value),
        "farm_humid": str(farm_humid.value),
        "farm_light": str(farm_light.value),
        "farm_irrigation": str(farm_irrigation.value),

        "predict1" : str(predict1[0][0]),
        "predict2" : str(predict2[0][0]),
        "predict3" : str(predict3[0][0]),
        "predict4" : str(predict4[0][0])
    }

    return render(request, 'index.html', context)


def on_message_light(client, userdata, msg):
    farm_light = Sensor.objects.get(name="farm_light")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(farm_light, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()

def on_message_humid(client, userdata, msg):
    farm_humid = Sensor.objects.get(name="farm_humid")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(farm_humid, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()

def on_message_irrigation(client, userdata, msg):
    farm_irrigation = Sensor.objects.get(name="farm_irrigation")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(farm_irrigation, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()

def on_message_soil(client, userdata, msg):
    farm_soil = Sensor.objects.get(name="farm_soil")
    data = {
        'value': msg.payload.decode('utf-8')
    }
    serializer = SensorSerializer(farm_soil, data=data, partial=True)
    if serializer.is_valid():
        serializer.save()



client = mqtt.Client("sensor")

client.message_callback_add('farm/irrigation', on_message_irrigation)
client.message_callback_add('farm/soil', on_message_soil)
client.message_callback_add('farm/humid', on_message_humid)
client.message_callback_add('farm/light', on_message_light)

client.connect('localhost', 1883)
client.loop_start()
client.subscribe('#')